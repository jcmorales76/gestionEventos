const pool = require("../config/db");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const { registrarAuditoria } = require("../utils/auditoria");

// Configuración de almacenamiento
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Carpeta plana e independiente de req.body: durante el parseo del
    // multipart, req.body.eventoId/sesion aún NO están poblados (llegaban
    // "undefined"). El evento y la sesión se guardan en columnas de la BD.
    const uploadPath = path.join(__dirname, "../uploads/materiales");

    // Crear carpeta si no existe
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }

    cb(null, uploadPath);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    // multer/busboy decodifica el nombre como latin1; recuperamos el UTF-8 real
    const originalUtf8 = Buffer.from(file.originalname, "latin1").toString(
      "utf8",
    );
    // nombre físico sin acentos ni espacios (evita problemas de URL/disco)
    const safe = originalUtf8
      .normalize("NFD")
      .replace(/\p{Diacritic}/gu, "")
      .replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, uniqueSuffix + "-" + safe);
  },
});

const fileFilter = (req, file, cb) => {
  const allowedTypes =
    /pdf|doc|docx|xls|xlsx|ppt|pptx|txt|zip|rar|jpg|jpeg|png|mp4|avi|mov/;
  const extname = allowedTypes.test(
    path.extname(file.originalname).toLowerCase(),
  );

  if (extname) {
    cb(null, true);
  } else {
    cb(new Error("Tipo de archivo no permitido"));
  }
};

const upload = multer({
  storage: storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB máximo
  fileFilter: fileFilter,
});

// ✅ Obtener materiales de un evento
const getMaterialesByEvento = async (req, res) => {
  try {
    const { eventoId } = req.params;
    const [materiales] = await pool.query(
      "SELECT * FROM materiales WHERE evento_id = ? ORDER BY sesion, fecha_subida DESC",
      [eventoId],
    );

    // Agrupar por sesiones
    const materialesPorSesion = {};
    materiales.forEach((m) => {
      if (!materialesPorSesion[m.sesion]) {
        materialesPorSesion[m.sesion] = [];
      }
      materialesPorSesion[m.sesion].push(m);
    });

    res.json(materialesPorSesion);
  } catch (error) {
    console.error("Error al obtener materiales:", error);
    res.status(500).json({ message: "Error al obtener materiales" });
  }
};

// ✅ Subir material
const uploadMaterial = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "No se subió ningún archivo" });
    }

    const { eventoId, sesion, descripcion } = req.body;

    const materialData = {
      evento_id: eventoId,
      sesion: sesion,
      nombre_original: Buffer.from(req.file.originalname, "latin1").toString(
        "utf8",
      ),
      nombre_archivo: req.file.filename,
      tipo_archivo: req.file.mimetype,
      tamaño: req.file.size,
      descripcion: descripcion || "",
      url_descarga: `/uploads/materiales/${req.file.filename}`,
    };

    const [result] = await pool.query(
      "INSERT INTO materiales (evento_id, sesion, nombre_original, nombre_archivo, tipo_archivo, tamaño, descripcion, url_descarga) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      [
        materialData.evento_id,
        materialData.sesion,
        materialData.nombre_original,
        materialData.nombre_archivo,
        materialData.tipo_archivo,
        materialData.tamaño,
        materialData.descripcion,
        materialData.url_descarga,
      ],
    );

    await registrarAuditoria(req, {
      accion: "subir",
      modulo: "materiales",
      entidad_id: result.insertId,
      descripcion: `Subió el material "${materialData.nombre_original}" (evento ${materialData.evento_id})`,
    });

    res.status(201).json({
      id: result.insertId,
      message: "Material subido exitosamente",
      data: materialData,
    });
  } catch (error) {
    console.error("Error al subir material:", error);
    res.status(500).json({ message: "Error al subir material" });
  }
};

// ✅ Eliminar material
const deleteMaterial = async (req, res) => {
  try {
    const { id } = req.params;

    // Obtener información del material
    const [materiales] = await pool.query(
      "SELECT * FROM materiales WHERE id = ?",
      [id],
    );

    if (materiales.length === 0) {
      return res.status(404).json({ message: "Material no encontrado" });
    }

    const material = materiales[0];

    // Eliminar archivo físico
    const filePath = path.join(__dirname, "..", material.url_descarga);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    // Eliminar de la base de datos
    await pool.query("DELETE FROM materiales WHERE id = ?", [id]);

    await registrarAuditoria(req, {
      accion: "eliminar",
      modulo: "materiales",
      entidad_id: Number(id) || null,
      descripcion: `Eliminó el material "${material.nombre_original}"`,
    });

    res.json({ message: "Material eliminado exitosamente" });
  } catch (error) {
    console.error("Error al eliminar material:", error);
    res.status(500).json({ message: "Error al eliminar material" });
  }
};

// ✅ Crear sesión
const crearSesion = async (req, res) => {
  try {
    const { eventoId, sesion } = req.body;

    await pool.query(
      "INSERT INTO materiales (evento_id, sesion, nombre_original, nombre_archivo, tipo_archivo, tamaño, descripcion, url_descarga) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
      [eventoId, sesion, "", "", "", 0, "", ""],
    );

    res.json({ message: "Sesión creada exitosamente" });
  } catch (error) {
    console.error("Error al crear sesión:", error);
    res.status(500).json({ message: "Error al crear sesión" });
  }
};

// ✅ Obtener sesiones de un evento
const getSesionesByEvento = async (req, res) => {
  try {
    const { eventoId } = req.params;
    const [sesiones] = await pool.query(
      'SELECT DISTINCT sesion FROM materiales WHERE evento_id = ? AND sesion != "" ORDER BY sesion',
      [eventoId],
    );

    res.json(sesiones.map((s) => s.sesion));
  } catch (error) {
    console.error("Error al obtener sesiones:", error);
    res.status(500).json({ message: "Error al obtener sesiones" });
  }
};

// ✅ Renombrar una sesión (carpeta) de un evento
const renombrarSesion = async (req, res) => {
  try {
    const { eventoId, sesionActual, sesionNueva } = req.body;
    if (!eventoId || !sesionActual || !sesionNueva || !sesionNueva.trim()) {
      return res.status(400).json({ message: "Faltan datos" });
    }
    await pool.query(
      "UPDATE materiales SET sesion = ? WHERE evento_id = ? AND sesion = ?",
      [sesionNueva.trim(), eventoId, sesionActual],
    );
    res.json({ message: "Sesión renombrada exitosamente" });
  } catch (error) {
    console.error("Error al renombrar sesión:", error);
    res.status(500).json({ message: "Error al renombrar la sesión" });
  }
};

// ✅ Eliminar una sesión (carpeta) completa: sus archivos físicos y registros
const eliminarSesion = async (req, res) => {
  try {
    const { eventoId, sesion } = req.body;
    if (!eventoId || !sesion) {
      return res.status(400).json({ message: "Faltan datos" });
    }
    const [mats] = await pool.query(
      "SELECT * FROM materiales WHERE evento_id = ? AND sesion = ?",
      [eventoId, sesion],
    );
    for (const m of mats) {
      if (m.url_descarga) {
        const filePath = path.join(__dirname, "..", m.url_descarga);
        if (fs.existsSync(filePath)) {
          try {
            fs.unlinkSync(filePath);
          } catch (e) {
            console.error("No se pudo borrar archivo:", e.message);
          }
        }
      }
    }
    await pool.query(
      "DELETE FROM materiales WHERE evento_id = ? AND sesion = ?",
      [eventoId, sesion],
    );
    res.json({ message: "Carpeta eliminada exitosamente" });
  } catch (error) {
    console.error("Error al eliminar sesión:", error);
    res.status(500).json({ message: "Error al eliminar la carpeta" });
  }
};

// ✅ EXPORTAR TODAS LAS FUNCIONES
module.exports = {
  upload,
  getMaterialesByEvento,
  uploadMaterial,
  deleteMaterial,
  crearSesion,
  getSesionesByEvento,
  renombrarSesion,
  eliminarSesion,
};
